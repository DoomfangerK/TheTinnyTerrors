--Readme--

The Tiny Terrors by Fanger

In the apocalyptic world that's broke into the biggest war in the history of man, two friends wander through the world as they try to survive. As a newcomer to their party, what will become of these two as you tag along with them.





I made this for the 2022 Ghost Jam, and I didn't have a team, so I did all the sprites, dialogue and coding y myself. Yay. It was fun, but unfortunately I ran out of time. I'm still going to continue it and update it if anyone cares to have two friends who banter on their screen. I planned it to become quite detailed as this lines up with something I'm doing with my friend. We're both huge fans of Undertale, so we're going to drop down to Mt. Ebott in a bit. There are base foundations for the code that I couldn't get to. There isn't a network set up, unfortunately, but I do hope to set one up for the next update.